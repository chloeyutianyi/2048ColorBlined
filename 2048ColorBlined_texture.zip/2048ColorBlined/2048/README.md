# 2048

JavaScript 实现的 2048 网页游戏

逻辑规则参考已有游戏，实现上没有参考源码。样式参考已有游戏。

<https://github.com/gabrielecirulli/2048>

## 示例

<http://luobotang.github.io/2048/app/>

![](2048.png)
