module.exports = {
	Left: 37,
	Up: 38,
	Right: 39,
	Down: 40
}